from typing import Optional
from Connection_pool import get_connection
import Database

class Property:
    def __init__(self, id: int, name: str, purchase_cost: int, base_rent: int,
                 owner_id: Optional[int], position: int, improvement_level: int, game_id: int):
        self.id = id
        self.name = name
        self.purchase_cost = purchase_cost
        self.base_rent = base_rent
        self.owner_id = owner_id
        self.position = position
        self.improvement_level = improvement_level
        self.game_id = game_id

    @classmethod
    def get(cls, property_id: int) -> Optional['Property']:
        with get_connection() as connection:
            data = Database.get_property(connection, property_id)
            if data:
                return cls(*data)
            return None

    def calculate_rent(self) -> int:
        return self.base_rent * (2 ** self.improvement_level)  # Rent doubles with each improvement

    def transfer_ownership(self, new_owner_id: Optional[int]):
        with get_connection() as connection:
            Database.update_property_owner(connection, self.id, new_owner_id)
            self.owner_id = new_owner_id
            print(f"Property ownership transferred {'to bank' if new_owner_id is None else f'to Player {new_owner_id}'}")

    def improve(self):
        with get_connection() as connection:
            Database.update_property_improvement(connection, self.id, self.improvement_level + 1)
            self.improvement_level += 1
            print(f"Property improved to level {self.improvement_level}")

    def get_improvement_cost(self) -> int:
        return self.purchase_cost // 2

    def __str__(self):
        status = f"Level {self.improvement_level}" if self.improvement_level > 0 else "No improvements"
        owner = f"Owner: Player {self.owner_id}" if self.owner_id else "For Sale!"
        improvement_cost = f"\nImprovement Cost: ${self.get_improvement_cost()}" if self.owner_id else ""
        return f"{self.name}\nPrice: ${self.purchase_cost}\nCurrent Rent: ${self.calculate_rent()}\n{status}\n{owner}{improvement_cost}"