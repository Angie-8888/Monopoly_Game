from typing import List, Tuple
from contextlib import contextmanager

# Type hints that exactly match database schema
Player = Tuple[int, str, int, int, int, int]  # id, name, money, turn_order, current_position, game_id
Property = Tuple[int, str, int, int, int, int, int, int]  # id, name, purchase_cost, base_rent, owner_id, position, improvement_level, game_id
Space = Tuple[int, str, str, str, int, int, int]  # id, name, description, action_type, action_value, position, game_id

# Create table queries
CREATE_TABLES = """
CREATE TABLE IF NOT EXISTS game_session (
    id SERIAL PRIMARY KEY,
    is_active BOOLEAN DEFAULT TRUE,
    starting_money INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS players (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    money INTEGER NOT NULL,
    turn_order INTEGER NOT NULL,
    current_position INTEGER DEFAULT 0,
    game_id INTEGER REFERENCES game_session(id)
);

CREATE TABLE IF NOT EXISTS properties (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    purchase_cost INTEGER NOT NULL,
    base_rent INTEGER NOT NULL,
    owner_id INTEGER REFERENCES players(id),
    position INTEGER NOT NULL,
    improvement_level INTEGER DEFAULT 0,
    game_id INTEGER REFERENCES game_session(id)
);

CREATE TABLE IF NOT EXISTS non_property_spaces (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    action_type TEXT NOT NULL,
    action_value INTEGER,
    position INTEGER NOT NULL,
    game_id INTEGER REFERENCES game_session(id)
);"""

@contextmanager
def get_cursor(connection):
    with connection:
        with connection.cursor() as cursor:
            yield cursor

def create_tables(connection):
    """Create all necessary tables"""
    with get_cursor(connection) as cursor:
        cursor.execute(CREATE_TABLES)

# Game functions
def create_game(connection, starting_money: int) -> int:
    """Create a new game and return its ID"""
    with get_cursor(connection) as cursor:
        cursor.execute(
            "INSERT INTO game_session (starting_money) VALUES (%s) RETURNING id",
            (starting_money,)
        )
        return cursor.fetchone()[0]

def get_active_game(connection):
    """Get the most recent active game"""
    with get_cursor(connection) as cursor:
        cursor.execute("""
            SELECT id, is_active, starting_money, created_at 
            FROM game_session 
            WHERE is_active = TRUE 
            ORDER BY created_at DESC 
            LIMIT 1
        """)
        return cursor.fetchone()

def end_game(connection, game_id: int):
    """End a game by setting is_active to False"""
    with get_cursor(connection) as cursor:
        cursor.execute(
            "UPDATE game_session SET is_active = FALSE WHERE id = %s",
            (game_id,)
        )

# Player functions
def add_player(connection, name: str, money: int, turn_order: int, game_id: int) -> int:
    """Add a new player and return their ID"""
    with get_cursor(connection) as cursor:
        cursor.execute(
            """INSERT INTO players (name, money, turn_order, game_id) 
            VALUES (%s, %s, %s, %s) RETURNING id""",
            (name, money, turn_order, game_id)
        )
        return cursor.fetchone()[0]

def get_player(connection, player_id: int) -> Player:
    """Get player by ID"""
    with get_cursor(connection) as cursor:
        cursor.execute(
            """SELECT id, name, money, turn_order, current_position, game_id 
            FROM players WHERE id = %s""",
            (player_id,)
        )
        return cursor.fetchone()

def get_game_players(connection, game_id: int) -> List[Player]:
    """Get all players in a game"""
    with get_cursor(connection) as cursor:
        cursor.execute(
            """SELECT id, name, money, turn_order, current_position, game_id 
            FROM players WHERE game_id = %s ORDER BY turn_order""",
            (game_id,)
        )
        return cursor.fetchall()

def update_player_money(connection, player_id: int, new_amount: int):
    """Update a player's money"""
    with get_cursor(connection) as cursor:
        cursor.execute(
            "UPDATE players SET money = %s WHERE id = %s",
            (new_amount, player_id)
        )

def update_player_position(connection, player_id: int, new_position: int):
    """Update a player's position on the board"""
    with get_cursor(connection) as cursor:
        cursor.execute(
            "UPDATE players SET current_position = %s WHERE id = %s",
            (new_position, player_id)
        )

# Property functions
def add_property(connection, name: str, cost: int, rent: int, position: int, game_id: int) -> int:
    """Add a new property and return its ID"""
    with get_cursor(connection) as cursor:
        cursor.execute(
            """INSERT INTO properties 
            (name, purchase_cost, base_rent, position, game_id) 
            VALUES (%s, %s, %s, %s, %s) RETURNING id""",
            (name, cost, rent, position, game_id)
        )
        return cursor.fetchone()[0]

def get_property(connection, property_id: int) -> Property:
    """Get property by ID"""
    with get_cursor(connection) as cursor:
        cursor.execute("""
            SELECT id, name, purchase_cost, base_rent, owner_id, position, 
                   improvement_level, game_id 
            FROM properties 
            WHERE id = %s""",
            (property_id,)
        )
        return cursor.fetchone()

def get_properties_by_game(connection, game_id: int) -> List[Property]:
    """Get all properties in a game"""
    with get_cursor(connection) as cursor:
        cursor.execute("""
            SELECT id, name, purchase_cost, base_rent, owner_id, position, 
                   improvement_level, game_id
            FROM properties 
            WHERE game_id = %s 
            ORDER BY position""",
            (game_id,)
        )
        return cursor.fetchall()

def update_property_owner(connection, property_id: int, new_owner_id: int):
    """Update a property's owner"""
    with get_cursor(connection) as cursor:
        cursor.execute(
            "UPDATE properties SET owner_id = %s WHERE id = %s",
            (new_owner_id, property_id)
        )

def update_property_improvement(connection, property_id: int, new_level: int):
    """Update a property's improvement level"""
    with get_cursor(connection) as cursor:
        cursor.execute(
            "UPDATE properties SET improvement_level = %s WHERE id = %s",
            (new_level, property_id)
        )

# Space functions
def add_space(connection, name: str, description: str, action_type: str,
              action_value: int, position: int, game_id: int) -> int:
    """Add a new non-property space and return its ID"""
    with get_cursor(connection) as cursor:
        cursor.execute(
            """INSERT INTO non_property_spaces 
            (name, description, action_type, action_value, position, game_id) 
            VALUES (%s, %s, %s, %s, %s, %s) RETURNING id""",
            (name, description, action_type, action_value, position, game_id)
        )
        return cursor.fetchone()[0]

def get_space(connection, space_id: int) -> Space:
    """Get non-property space by ID"""
    with get_cursor(connection) as cursor:
        cursor.execute("""
            SELECT id, name, description, action_type, action_value, position, game_id 
            FROM non_property_spaces WHERE id = %s""",
            (space_id,)
        )
        return cursor.fetchone()

def get_spaces_by_game(connection, game_id: int) -> List[Space]:
    """Get all non-property spaces in a game"""
    with get_cursor(connection) as cursor:
        cursor.execute("""
            SELECT id, name, description, action_type, action_value, position, game_id 
            FROM non_property_spaces 
            WHERE game_id = %s 
            ORDER BY position""",
            (game_id,)
        )
        return cursor.fetchall()


def clear_board(connection, game_id: int):
    with get_cursor(connection) as cursor:
        cursor.execute("DELETE FROM properties WHERE game_id = %s", (game_id,))
        cursor.execute("DELETE FROM non_property_spaces WHERE game_id = %s", (game_id,))
        connection.commit()



def reset_game_data(connection):
    """Reset all game data in database"""
    with get_cursor(connection) as cursor:
        cursor.execute("TRUNCATE non_property_spaces, properties, players, game_session RESTART IDENTITY CASCADE;")