from typing import Optional
from Connection_pool import get_connection
import Database

class Game:
    def __init__(self, id: int, is_active: bool, starting_money: int, created_at=None):
        self.id = id
        self.is_active = is_active
        self.starting_money = starting_money
        self.created_at = created_at
        self._current_player_index = 0

    @property
    def current_player_index(self):
        return self._current_player_index

    def next_player(self):
        player_count = len(self.players)
        if player_count > 0:
            self._current_player_index = (self._current_player_index + 1) % player_count
            return self.players[self._current_player_index]
        return None

    @classmethod
    def create(cls, starting_money: int = 1500) -> 'Game':
        with get_connection() as connection:
            game_id = Database.create_game(connection, starting_money)
            return cls(game_id, True, starting_money)

    @classmethod
    def get_active(cls) -> Optional['Game']:
        with get_connection() as connection:
            game_data = Database.get_active_game(connection)
            if game_data:
                id_, is_active, starting_money, created_at = game_data
                return cls(id=id_, is_active=is_active, starting_money=starting_money, created_at=created_at)
            return None

    @property
    def players(self):
        from Player import Player
        with get_connection() as connection:
            return [Player(*data) for data in Database.get_game_players(connection, self.id)]

    @property
    def properties(self):
        from Property import Property
        with get_connection() as connection:
            return [Property(*data) for data in Database.get_properties_by_game(connection, self.id)]

    @property
    def spaces(self):
        from NonProperty import NonPropertySpace
        with get_connection() as connection:
            return [NonPropertySpace(*data) for data in Database.get_spaces_by_game(connection, self.id)]

    def add_player(self, name: str):
        with get_connection() as connection:
            player_count = len(self.players)
            player_id = Database.add_player(connection, name, self.starting_money, player_count, self.id)
            from Player import Player
            return Player.get(player_id)

    def initialize_board(self):
        with get_connection() as connection:
            Database.clear_board(connection, self.id)
            properties = [
                ("Mediterranean Avenue", 60, 2, 1),
                ("Baltic Avenue", 60, 4, 3),
                ("Reading Railroad", 200, 25, 5),
                ("Oriental Avenue", 100, 6, 15),
                ("Vermont Avenue", 100, 6, 17),
                ("Connecticut Avenue", 120, 8, 19)
            ]
            spaces = [
                ("GO", "Collect $200", "COLLECT", 200, 0),
                ("Chance", "Draw a chance card", "CHANCE", 0, 2),
                ("Income Tax", "Pay $200", "PAY", 200, 4),
                ("Jail", "Just visiting", "NONE", 0, 10),
                ("Free Parking", "Rest here", "NONE", 0, 20)
            ]
            for name, cost, rent, position in properties:
                Database.add_property(connection, name, cost, rent, position, self.id)
            for name, desc, action_type, value, position in spaces:
                Database.add_space(connection, name, desc, action_type, value, position, self.id)

    def end_game(self):
        with get_connection() as connection:
            Database.end_game(connection, self.id)
            self.is_active = False

    def __str__(self):
        return f"Game {self.id} - {'Active' if self.is_active else 'Ended'}"