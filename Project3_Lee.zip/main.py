from typing import Optional
import random
from Connection_pool import get_connection
import Database
from Game import Game
from Player import Player
from Property import Property
from NonProperty import NonPropertySpace

MENU_PROMPT = """-- Monopoly Game Menu --

1) Start new game
2) Add player to game
3) Initialize board
4) Play game
5) Show game status
6) Exit

Enter your choice: """

GAME_PROMPT = """-- Game Actions --

1) Roll dice
2) Buy property
3) Improve property
4) Sell property
5) Show player status
6) Show board status
7) End turn
8) End game

Enter your choice: """

def menu():
    current_game = Game.get_active()
    selection = input(MENU_PROMPT)

    if selection == "1":
        with get_connection() as connection:
            Database.reset_game_data(connection)
        current_game = prompt_start_game()
    elif selection == "2":
        prompt_add_player(current_game)
    elif selection == "3":
        initialize_board(current_game)
    elif selection == "4":
        if not current_game or not current_game.properties:
            print("Please start a new game and initialize the board first!")
        elif len(current_game.players) < 2:
            print("Need at least 2 players to start! Add more players.")
        else:
            play_game(current_game)
    elif selection == "5":
        if current_game:
            show_player_status(current_game)
            show_board_status(current_game)
        else:
            print("No active game!")
    elif selection == "6":
        print("Thanks for playing!")
        return
    else:
        print("Invalid choice, please try again.")

    menu()

def prompt_start_game() -> Optional[Game]:
    print("\n=== Starting New Game ===")
    try:
        starting_money = int(input("Enter starting money for each player (default 1500): ") or 1500)
        game = Game.create(starting_money)
        print(f"Game created successfully! Game ID: {game.id}")
        return game
    except ValueError as e:
        print(f"Error creating game: {e}")
        return None

def prompt_add_player(game: Game) -> Optional[Player]:
    print("\n=== Adding New Player ===")
    if not game:
        print("No active game! Please start a new game first.")
        return None

    try:
        name = input("Enter player name: ")
        player = game.add_player(name)
        print(f"Player {name} added successfully!")
        return player
    except Exception as e:
        print(f"Error adding player: {e}")
        return None

def initialize_board(game: Game):
    print("\n=== Initializing Game Board ===")
    if not game:
        print("No active game! Please start a new game first.")
        return

    try:
        game.initialize_board()
        print("Board initialized successfully!")
    except Exception as e:
        print(f"Error initializing board: {e}")

def roll_dice() -> int:
    dice1 = random.randint(1, 6)
    dice2 = random.randint(1, 6)
    print(f"Rolled: {dice1} + {dice2} = {dice1 + dice2}")
    return dice1 + dice2

def play_game(game: Game):
    if not game:
        print("No active game! Please start a new game first.")
        return

    players = game.players
    if not players:
        print("No players in the game! Please add players first.")
        return

    turn_ongoing = True
    current_player_idx = 0

    while turn_ongoing:
        current_player = players[current_player_idx]
        print(f"\n=== {current_player.name}'s Turn ===")

        choice = input(GAME_PROMPT)

        if choice == "1":  # Roll dice
            spaces = roll_dice()
            current_player.move(spaces)
            handle_space(current_player, game)
        elif choice == "2":  # Buy property
            handle_buy_action(current_player, game)
        elif choice == "3":  # Improve property
            show_owned_properties(current_player, game)
            handle_improve_property(current_player)
        elif choice == "4":  # Sell property
            show_owned_properties(current_player, game)
            handle_sell_property(current_player)
        elif choice == "5":  # Show player status
            show_player_status(game)
        elif choice == "6":  # Show board status
            show_board_status(game)
        elif choice == "7":  # End turn
            current_player_idx = (current_player_idx + 1) % len(players)
            next_player = players[current_player_idx]
            print(f"\nTurn ended. Next player: {next_player.name}")
        elif choice == "8":  # End game
            game.end_game()
            turn_ongoing = False
            print("Game ended!")
        else:
            print("Invalid choice, please try again.")

def handle_space(player: Player, game: Game):
    property = next((p for p in game.properties if p.position == player.position), None)
    space = next((s for s in game.spaces if s.position == player.position), None)

    if property:
        print(f"\nLanded on: {property}")
        handle_property_space(player, property)
    elif space:
        print(f"\nLanded on: {space}")
        space.execute_action(player)
    else:
        print("Empty space")

def handle_property_space(player: Player, property: Property):
    if not property.owner_id:
        if player.money >= property.purchase_cost:
            if input(f"Buy {property.name} for ${property.purchase_cost}? (y/n) ").lower() == 'y':
                try:
                    player.pay(property.purchase_cost)
                    property.transfer_ownership(player.id)
                    print(f"Successfully purchased {property.name}!")
                except ValueError as e:
                    print(f"Error: {e}")
        else:
            print("Insufficient funds to purchase this property.")
    elif property.owner_id != player.id:
        rent = property.calculate_rent()
        print(f"This property is owned by Player {property.owner_id}. Paying ${rent} in rent.")
        try:
            player.pay(rent)
            owner = Player.get(property.owner_id)
            if owner:
                owner.receive(rent)
        except ValueError as e:
            print(f"Error: {e}")

def handle_buy_action(player: Player, game: Game):
    property = next((p for p in game.properties if p.position == player.position), None)
    if property:
        if property.owner_id is None:
            handle_buy_property(player, property)
        else:
            print(f"This property is already owned by Player {property.owner_id}")
    else:
        print("You must be on a property space to buy it!")

def show_owned_properties(player: Player, game: Game):
    properties = [p for p in game.properties if p.owner_id == player.id]
    if properties:
        print("\nYour Properties:")
        for prop in properties:
            print(f"ID: {prop.id} - {prop.name}")
            print(f"  Position: {prop.position}")
            print(f"  Improvements: {prop.improvement_level}")
            print(f"  Current Rent: ${prop.calculate_rent()}")
    else:
        print("\nYou don't own any properties.")

def handle_buy_property(player: Player, property: Property):
    if player.money >= property.purchase_cost:
        try:
            player.pay(property.purchase_cost)
            property.transfer_ownership(player.id)
            print("Property purchased successfully!")
        except ValueError as e:
            print(f"Error: {e}")
    else:
        print("Insufficient funds to purchase this property.")

def handle_improve_property(player: Player):
    try:
        property_id = int(input("Enter property ID to improve: "))
        property = Property.get(property_id)
        if property and property.owner_id == player.id:
            improvement_cost = property.get_improvement_cost()
            if player.money >= improvement_cost:
                player.pay(improvement_cost)
                property.improve()
                print("Property improved successfully!")
            else:
                print(f"Insufficient funds. Need ${improvement_cost}")
        else:
            print("Invalid property ID or you don't own this property.")
    except ValueError as e:
        print(f"Error: {e}")

def handle_sell_property(player: Player):
    try:
        property_id = int(input("Enter property ID to sell: "))
        property = Property.get(property_id)
        if property and property.owner_id == player.id:
            sell_price = property.get_improvement_cost()
            player.receive(sell_price)
            property.transfer_ownership(None)
            print(f"Property sold for ${sell_price}")
        else:
            print("Invalid property ID or you don't own this property.")
    except ValueError as e:
        print(f"Error: {e}")

def show_player_status(game: Game):
    print("\n=== Player Status ===")
    for player in game.players:
        properties = [p for p in game.properties if p.owner_id == player.id]
        print(f"\n{player.name}:")
        print(f"Money: ${player.money}")
        print(f"Position: {player.position}")

        space = next((s for s in game.spaces if s.position == player.position), None)
        property = next((p for p in game.properties if p.position == player.position), None)
        if space:
            print(f"Currently on: {space.name} (Space)")
        elif property:
            print(f"Currently on: {property.name} (Property)")

        if properties:
            print("Properties owned:")
            for prop in properties:
                print(f"- {prop.name}")
                print(f"  Improvements: Level {prop.improvement_level}")
                print(f"  Current Rent: ${prop.calculate_rent()}")
        else:
            print("No properties owned")

def show_board_status(game: Game):
    print("\n=== Board Status ===")
    spaces = [(p.position, str(p)) for p in game.properties]
    spaces.extend([(s.position, str(s)) for s in game.spaces])
    spaces.sort(key=lambda x: x[0])

    for position, description in spaces:
        print(f"\nPosition {position}:")
        print(description)

if __name__ == "__main__":
    with get_connection() as connection:
        Database.create_tables(connection)
    menu()