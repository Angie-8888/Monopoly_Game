import os
from contextlib import contextmanager
import psycopg2
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Database URL for Supabase
DATABASE_URL = "postgresql://postgres.qjwzlpcckneiljbtqnwb:D#z!8GE9PTS4ME7@aws-0-us-east-2.pooler.supabase.com:6543/postgres"

@contextmanager
def get_connection():
    """Create and manage a database connection"""
    conn = None
    try:
        conn = psycopg2.connect(DATABASE_URL)
        yield conn
    finally:
        if conn is not None:
            conn.close()