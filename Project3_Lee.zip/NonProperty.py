from typing import Optional
from Connection_pool import get_connection
import Database

class NonPropertySpace:
    def __init__(self, id: int, name: str, description: str, action_type: str,
                 action_value: int, position: int, game_id: int):
        self.id = id
        self.name = name
        self.description = description
        self.action_type = action_type
        self.action_value = action_value
        self.position = position
        self.game_id = game_id

    @classmethod
    def get(cls, space_id: int) -> Optional['NonPropertySpace']:
        with get_connection() as connection:
            data = Database.get_space(connection, space_id)
            if data:
                return cls(*data)
            return None

    def execute_action(self, player: 'Player'):
        if self.action_type == "COLLECT":
            player.receive(self.action_value)
        elif self.action_type == "PAY":
            player.pay(self.action_value)
        elif self.action_type == "CHANCE":
            pass  # Future chance card implementation

    def __str__(self):
        return f"{self.name}\n{self.description}"