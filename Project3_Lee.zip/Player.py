from typing import Optional
from Connection_pool import get_connection
import Database


class Player:
    def __init__(self, id: int, name: str, money: int, turn_order: int, current_position: int, game_id: int):
        self.id = id
        self.name = name
        self.money = money
        self.turn_order = turn_order
        self.position = current_position
        self.game_id = game_id

    @classmethod
    def get(cls, player_id: int) -> Optional['Player']:
        with get_connection() as connection:
            data = Database.get_player(connection, player_id)
            if data:
                return cls(*data)
            return None

    def move(self, spaces: int):
        old_position = self.position
        new_position = (old_position + spaces) % 20

        with get_connection() as connection:
            if new_position < old_position:
                self.receive(200)
                print("Passed GO! Collected $200")

            Database.update_player_position(connection, self.id, new_position)
            self.position = new_position

    def pay(self, amount: int):
        if amount > self.money:
            raise ValueError(f"Not enough money! Need ${amount}, have ${self.money}")

        with get_connection() as connection:
            Database.update_player_money(connection, self.id, self.money - amount)
            self.money -= amount

    def receive(self, amount: int):
        with get_connection() as connection:
            Database.update_player_money(connection, self.id, self.money + amount)
            self.money += amount

    def __str__(self):
        return f"{self.name} (${self.money})"